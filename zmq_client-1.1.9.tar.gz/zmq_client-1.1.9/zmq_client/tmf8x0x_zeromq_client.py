# *****************************************************************************
# * Copyright by ams OSRAM AG                                                 *
# * All rights are reserved.                                                  *
# *                                                                           *
# * IMPORTANT - PLEASE READ CAREFULLY BEFORE COPYING, INSTALLING OR USING     *
# * THE SOFTWARE.                                                             *
# *                                                                           *
# * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       *
# * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         *
# * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS         *
# * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  *
# * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     *
# * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          *
# * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES LOSS OF USE,      *
# * DATA, OR PROFITS OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY      *
# * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       *
# * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     *
# * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      *
# *****************************************************************************
"""
ZeroMQ client.
"""
import csv
import logging
import time
from io import TextIOWrapper
from pathlib import Path
from threading import Thread
from typing import Any, List, Optional, Union

import zmq

from .tmf8x0x_zeromq_common import (
    DEFAULT_CMD_SERVER_ADDR,
    DEFAULT_RESULT_SERVER_ADDR,
    CommandError,
    CommandId,
    DeviceInfo,
    ErrorCodes,
    HistogramConfig,
    HistogramsAndResult,
    PersistenceThresholdConfig,
    RequestMessage,
    ResponseMessage,
    ResultContainer,
)
from .tmf8806_regs import tmf8806MeasureCmd

__all__ = [
    "CSVDataLogger",
    "ZeroMqClient",
]

logger = logging.getLogger(__name__)


class CSVDataLogger:
    """
    CSV logger for histogram and result data.

    Args:
        result_addr: Result server address.
    """

    def __init__(self, result_addr: str) -> None:

        self._server_addr = result_addr
        self._context = zmq.Context()
        self._result_socket = self._context.socket(zmq.SUB)
        self._stop_logging = True
        self._log_thread = None
        self._dev_info = None
        self._meas_cfg = None

    def _convert_data(self, data: HistogramsAndResult, distance_correction_factor: float = 1.0) -> List[List[Any]]:
        """
        Convert histogram and result data to CSV format.

        Args:
            data: Histogram and result data.

            distance_correction_factor: Factor to correct measured distances.

        Returns:
            Converted histogram und result data.
        """
        rows = []
        for i, hist in enumerate(data.histogramsEc):
            rows.append([f"#CI{i}"] + list(hist))

        for i, hist in enumerate(data.histogramsOc):
            rows.append([f"#CO{i}"] + list(hist))

        for i, hist in enumerate(data.histogramsProx):
            rows.append([f"#PT{i}"] + list(hist))

        for i, hist in enumerate(data.histogramsDist):
            rows.append([f"#TG{i}"] + list(hist))

        for i, hist in enumerate(data.histogramsProcPuc):
            rows.append([f"#PTPUC{i+1}"] + list(hist))

        for i, hist in enumerate(data.histogramsDistPuc):
            rows.append([f"#TGPUC{i+1}"] + list(hist))

        if data.histogramSum:
            rows.append(["#SUM"] + data.histogramSum)

        rows.append(["#RES"] + list(bytes(data.result)))

        row = ["#OBJ", str(int(time.time() * 1000))]
        if int(data.result.reliability) > 0:
            row += [
                1,  # number of detected objects
                data.result.reliability,  # confidence level of object
                round(int(data.result.distPeak) * distance_correction_factor),
                data.result.referenceHits,  # reference photon count
                data.result.objectHits,  # object photon count
            ]
        else:
            row += [0] * 5
        rows.append(row)

        rows.append(["#TMP", data.result.temperature])
        return rows

    def _write_log_header(self, fp: TextIOWrapper) -> None:
        """
        Write the log header to the log file

        Args:
            fp: Log file.
        """
        fp.write("sep=;\n")
        fp.write("#OBJ;Timestamp;Number of Objects;Confidence;Center Distance of Object;"
                 "Reference Photon Count;Object Photon Count\n")
        fp.write("#TMP;Temperature Measurement SPAD Celsius\n")

        if self._meas_cfg is not None:
            fp.write("#ITT;Iterations;Object Detection Threshold\n")
            fp.write(f"#ITT;{self._meas_cfg.data.kIters};{self._meas_cfg.data.snr.threshold}\n")

        if self._dev_info is not None:
            fp.write("#VER;ToF Serial Number;App0 Version Number;GUI Version Number;"
                     "Host Driver Version Number;Chip ID;Chip Revision\n")
            fp.write(f"#VER;{self._dev_info.sensor_serial};{self._dev_info.fw_version};0.0.0.0;0.0.0.0;7;3\n")

    def _log_data(self, log_file: Union[Path, str]) -> None:
        """
        Wait for result data and log the data.
        """
        self._result_socket.connect(self._server_addr)
        self._result_socket.setsockopt(zmq.SUBSCRIBE, b'')
        logger.info("Connect to server")

        logger.info("Start data logging.")
        with open(log_file, mode="w", newline="", encoding="utf-8") as f:
            self._write_log_header(f)
            log = csv.writer(f, delimiter=";")

            while not self._stop_logging:
                event = self._result_socket.poll(timeout=0.1)
                if zmq.POLLIN == event:
                    result = ResultContainer(buffer=self._result_socket.recv(copy=True)).results
                    if result is not None:
                        log.writerows(self._convert_data(data=result))
        logger.info("Stop data logging.")

        self._result_socket.disconnect(self._server_addr)
        logger.info("Disconnect from server")

    def start_logging(self,
                      log_file: Union[Path, str],
                      meas_cfg: Optional[tmf8806MeasureCmd] = None,
                      device_info: Optional[DeviceInfo] = None,
                      ) -> None:
        """
        Start histogram and result data logging.

        Args:
            log_file: Logging file name.
        """
        self._dev_info = device_info
        self._meas_cfg = meas_cfg
        if self._log_thread is None:
            self._stop_logging = False
            self._log_thread = Thread(target=self._log_data,
                                      args=[log_file],
                                      name="ZeroMQ data logger")
            self._log_thread.start()

    def stop_logging(self) -> None:
        """
        Stop histogram and result data logging.
        """
        self._stop_logging = True
        if self._log_thread is not None:
            self._log_thread.join(timeout=5.0)
            if self._log_thread.is_alive():
                logger.error("Result thread is still alive.")
            self._log_thread = None


class ZeroMqClient:
    """ZeroMQ client"""

    def __init__(self) -> None:
        self._context = zmq.Context()
        self._cmd_socket = self._context.socket(zmq.REQ)
        self._result_socket = self._context.socket(zmq.SUB)
        self._cmd_addr = None
        self._result_addr = None
        self._data_logger = None

    def connect(self, cmd_addr=DEFAULT_CMD_SERVER_ADDR, result_addr=DEFAULT_RESULT_SERVER_ADDR):
        """
        Connect to server.

        Args:
            cmd_addr: Command server address.

            result_addr: Result server address.
        """
        self._cmd_addr = cmd_addr
        self._result_addr = result_addr
        self._cmd_socket.connect(self._cmd_addr)
        self._result_socket.connect(self._result_addr)
        self._result_socket.getsockopt_string
        self._result_socket.setsockopt(zmq.SUBSCRIBE, b'')
        logger.info("Connect to server")

    def disconnect(self):
        """Disconnect from server."""
        if self._cmd_addr is not None:
            self._cmd_socket.disconnect(self._cmd_addr)
        if self._result_addr is not None:
            self._result_socket.disconnect(self._result_addr)
        logger.info("Disconnect from server")

    def _send_request(self, request: RequestMessage) -> ResponseMessage:
        """
        Send a request to the server and wait for response.

        Args:
            request: Request message to send.

        Returns:
            Response message.

        Raises:
            CommandError: Request failed.
        """

        logger.debug("Sending request %s", request)
        self._cmd_socket.send(request.to_buffer())

        #  Get the reply.
        response = ResponseMessage(buffer=self._cmd_socket.recv(copy=True))
        logger.debug("Received reply %s [ %s ]", request, response)

        if response.error_code != ErrorCodes.NO_ERROR:
            raise CommandError

        return response

    def identify(self) -> DeviceInfo:
        """
        Identify the EVM controller and the target sensor.

        Returns:
            Device information

        Raises:
            CommandError: Identify request failed.
        """
        resp = self._send_request(RequestMessage(command_id=CommandId.IDENTIFY))
        return DeviceInfo(buffer=resp.payload)

    def start_measurement(self, config: tmf8806MeasureCmd) -> bool:
        """
        Start measurement.

        Args:
            config: Measurement configuration.

        Returns:
            `True` if measurement started with calibration data and `False`if not.

        Raises:
            CommandError: Start measurement failed.
        """
        resp = self._send_request(RequestMessage(command_id=CommandId.START_MEASUREMENT,
                                                 payload=bytes(config)))
        return bool(resp.payload[0])

    def stop_measurement(self) -> None:
        """
        Stop measurement.

        Raises:
            CommandError: Stop measurement failed.
        """
        self._send_request(RequestMessage(command_id=CommandId.STOP_MEASUREMENTS))

    def clear_calibration(self, config: tmf8806MeasureCmd) -> None:
        """
        Clear the calibration data for the given configuration.

        Args:
            config: Measurement configuration

        Raises:
            CommandError: Clear calibration data failed.
        """
        self._send_request(RequestMessage(command_id=CommandId.CLEAR_CALIBRATION,
                                         payload=bytes(config)))

    def get_configuration(self) -> tmf8806MeasureCmd:
        """
        Get measurement configuration.

        Returns:
            Measurement configuration.
        """
        resp = self._send_request(RequestMessage(command_id=CommandId.GET_CONFIGURATION))
        return tmf8806MeasureCmd.from_buffer_copy(resp.payload)

    def set_histogram_config(self, config: HistogramConfig) -> None:
        """
        Configures histogram dumping.

        Args:
            config: Histogram dumping configuration.
        """
        self._send_request(RequestMessage(command_id=CommandId.SET_HISTOGRAM_CFG,
                                         payload=config.to_buffer()))

    def get_histogram_config(self) -> HistogramConfig:
        """
        Get histogram dumping configuration.

        Returns:
            Histogram dumping configuration.
        """
        resp = self._send_request(RequestMessage(command_id=CommandId.GET_HISTOGRAM_CFG))
        return HistogramConfig(buffer=resp.payload)

    def set_persistence_threshold_config(self, config: PersistenceThresholdConfig) -> None:
        """
        Configures persistence and threshold.

        Args:
            config: Persistence and threshold configuration.
        """
        self._send_request(RequestMessage(command_id=CommandId.SET_PERSISTENCE_AND_THRESHOLD,
                                         payload=config.to_buffer()))

    def get_persistence_threshold_config(self) -> PersistenceThresholdConfig:
        """
        Get persistence and threshold configuration.

        Returns:
            Persistence and threshold configuration.
        """
        resp = self._send_request(RequestMessage(command_id=CommandId.GET_PERSISTENCE_AND_THRESHOLD))
        return PersistenceThresholdConfig(buffer=resp.payload)

    def get_data(self) -> HistogramsAndResult:
        """
        Read result data.

        Returns:
            Result data.
        """
        return ResultContainer(buffer=self._result_socket.recv(copy=True)).results

    def start_logging(self, log_file: Union[Path, str]) -> None:
        """
        Start histogram and result data logging.

        Args:
            log_file: Logging file name.
        """
        if self._result_addr is None:
            raise CommandError("Client is not connected.")
        self._data_logger = CSVDataLogger(result_addr=self._result_addr)
        self._data_logger.start_logging(log_file=log_file)


    def stop_logging(self) -> None:
        """
        Stop histogram and result data logging.
        """
        if self._data_logger is not None:
            self._data_logger.stop_logging()
            self._data_logger = None

    def update_target_binaries(self, zip_file: Union[Path, str]) -> None:
        """
        Update EVM software on target.

        Args:
            zip_file: Zipped update software.
        """
        with open(zip_file, mode="rb") as f:
            self._send_request(RequestMessage(command_id=CommandId.UPDATE_TARGET_BINARIES,
                                              payload=f.read()))
