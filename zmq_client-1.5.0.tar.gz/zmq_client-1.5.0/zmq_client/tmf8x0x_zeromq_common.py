# /*****************************************************************************
# * Copyright (c) [2024] ams-OSRAM AG                                          *
# * All rights are reserved.                                                   *
# *                                                                            *
# * FOR FULL LICENSE TEXT SEE LICENSE.TXT                                      *
# ******************************************************************************/
 

"""
ZeroMQ common functions and classes.
"""
import logging
from ctypes import sizeof
from enum import IntEnum, IntFlag
from pathlib import Path
from struct import iter_unpack
from typing import Any, Iterable, List, Optional, Union

from .tmf8806_regs import (
    tmf8806ContainerFrameHeader,
    tmf8806DistanceResultFrame,
    tmf8806FactoryCalibData,
    tmf8806MeasureCmd,
)

logger = logging.getLogger(__name__)

EVM_VERSION = "1.5.0"
DEFAULT_CMD_SERVER_ADDR = "tcp://127.0.0.1:5555"
DEFAULT_RESULT_SERVER_ADDR = "tcp://127.0.0.1:5556"
FW_PATCH_FILE = Path(__file__).parent / "fw_patch/mainapp_PATCH_Maxwell.hex"


class ProtocolError(Exception):
    """Command protocol error"""


class CommandError(Exception):
    """Command error."""


class CommandId(IntEnum):
    """Request command IDs."""
    NONE = 0x00
    IDENTIFY = 0x01
    START_MEASUREMENT = 0x10
    GET_CONFIGURATION = 0x11
    STOP_MEASUREMENTS = 0x12
    CLEAR_CALIBRATION = 0x15
    GET_CALIBRATION = 0x16
    SET_HISTOGRAM_CFG = 0x20
    GET_HISTOGRAM_CFG = 0x21
    SET_PERSISTENCE_AND_THRESHOLD = 0x30
    GET_PERSISTENCE_AND_THRESHOLD = 0x31
    SET_DRIVER_CFG = 0x80
    GET_DRIVER_CFG = 0x81
    UPDATE_TARGET_BINARIES = 0xA0


class ErrorCodes(IntEnum):
    """Error codes"""
    NO_ERROR = 0x00  #: No error
    UNKNOWN_CMD = 0xfe  #: Unknown command
    ERROR = 0xff  #: Error


class EvmCtrlId(IntEnum):
    """EVM Controller IDs"""
    FTDI = 0
    ARDUINO = 1
    RASPI = 2


class HistogramFlags(IntFlag):
    """Histogram dumping flags"""
    NONE = 0
    ELECTRICAL_CAL = 1
    PROXIMITY = 2
    DISTANCE = 4
    ALG_PILEUP = 8
    ALG_PU_TDC_SUM = 16

class MeasureCommand(IntEnum):
    """Measurement commands."""
    FACTORY_CALIB = 0x0a  #: Run factory calibration
    MEASURE = 0x02  #: Run measurement


class FWProgramID(IntEnum):
    """FW program IDs"""
    BOOT_LOADER = 0x80  #: Bootloader
    APP0 = 0xc0  #: Application


class RequestMessage:
    """
    ZeroMQ request message.

    Args:
        command_id: Command ID.

        payload: Message payload.

        buffer: Optional. Serialized request message.

    Attributes:
        command_id (CommandId): Command ID.

        payload (bytes): Message payload.
    """

    def __init__(self, command_id=CommandId.NONE, payload=b'', buffer: Optional[bytes] = None) -> None:
        self.command_id = command_id
        self.payload = payload
        if buffer is not None:
            self.from_buffer(buffer)

    def __str__(self) -> str:
        return f"Request 0x{self.command_id:02x} {self.payload!r}"

    def to_buffer(self) -> bytes:
        """
        Serialize the request message to byte buffer.

        Returns:
            Serialized request message.
        """
        return self.command_id.to_bytes(1, 'little') + self.payload

    def from_buffer(self, buffer: bytes) -> None:
        """
        Recover the request from byte buffer.

        Args:
            buffer: Request message serialized as byte buffer.
        """
        self.command_id = buffer[0]
        self.payload = buffer[1:]


class ResponseMessage:
    """
    ZeroMQ response message.

    Args:
        error_code: Error code.

        payload: Message payload as byte buffer.

        buffer: Optional. Serialized response message.

    Attributes:
        error_code (int): Error code.

        payload (bytes): Message payload.
    """

    def __init__(self, error_code=ErrorCodes.NO_ERROR, payload=b'', buffer: Optional[bytes] = None) -> None:
        self.error_code = error_code
        self.payload = payload
        if buffer is not None:
            self.from_buffer(buffer)

    def __str__(self) -> str:
        return f"Response 0x{self.error_code:02x} {self.payload!r}"

    def to_buffer(self) -> bytes:
        """
        Serialize the response message to byte buffer.

        Returns:
            Serialized response message.
        """
        return bytes([self.error_code]) + self.payload

    def from_buffer(self, buffer: bytes) -> None:
        """
        Recover the response from byte buffer:

        Args:
            buffer: Response buffer serialized as byte buffer.
        """
        self.error_code = buffer[0]
        self.payload = buffer[1:]


class DeviceInfo:
    """
    Collection of some device information.

    Args:
        buffer: Optional. Serialized device info.

    Attributes:
        protocol_version (int): Version of the communication protocol.

        evm_controller_id (int): ID of the used EVM controller.

        sensor_serial (int): Sensor serial number.

        fw_version (int): Sensor firmware version.

        host_driver_version (int): Version of the host driver.

        evm_version (str): EVM version string.
    """

    def __init__(self, buffer: Optional[bytes] = None) -> None:
        self.protocol_version = 0
        self.evm_controller_id = 0
        self.sensor_serial = 0
        self.fw_version = 0
        self.host_driver_version = 0
        self.evm_version = ""
        if buffer is not None:
            self.from_buffer(buffer)

    def to_buffer(self) -> bytes:
        """
        Serialize the device information to byte buffer.

        Returns:
            Serialized device information.
        """
        buffer = (
            self.protocol_version.to_bytes(1, "little")
            + self.evm_controller_id.to_bytes(3, "little")
            + self.sensor_serial.to_bytes(4, "little")
            + self.fw_version.to_bytes(4, "little")
            + self.host_driver_version.to_bytes(4, "little")
            + self.evm_version.encode().ljust(8)[:8]
        )
        return buffer + bytes(8)

    def from_buffer(self, buffer: bytes) -> None:
        """
        Recover device information from byte buffer.

        Args:
            buffer: Device information serialized as byte buffer.
        """
        self.protocol_version = buffer[0]
        self.evm_controller_id = int().from_bytes(buffer[1:4], "little")
        self.sensor_serial = int().from_bytes(buffer[4:8], "little")
        self.fw_version = int().from_bytes(buffer[8:12], "little")
        self.host_driver_version = int().from_bytes(buffer[12:16], "little")
        self.evm_version = buffer[16:24].decode()


class HistogramConfig:
    """
    Histogram dump configuration.

    Args:
        elect_calib: Enable electrical calibration histogram dumping. Default to `False`.

        prox: Enable proximity histogram dumping. Default to `False`.

        distance (bool, optional): Enable distance histograms dumping. Defaults to False.

        distance_puc (bool, optional): Enable pile-up corrected distance histograms dumping. Defaults to False.

        summed (bool, optional): Enable pile-up corrected summed histogram dumping. Defaults to False.


    Attributes:
        elect_calib (bool): Dump electrical calibration histogram.

        prox (bool): Dump proximity histogram.

        distance (bool): Dump distance histograms.

        distance_puc (bool): Dump pile-up corrected distance histograms.

        summed (bool): Dump a pile-up corrected summed histogram.
    """

    def __init__(self,
                 elect_calib=False,
                 prox=False,
                 distance=False,
                 distance_puc=False,
                 summed=False,
                 buffer: Optional[bytes] = None,
                 ) -> None:
        self.elect_calib = elect_calib
        self.prox = prox
        self.distance = distance
        self.distance_puc = distance_puc
        self.summed = summed
        if buffer is not None:
            self.from_buffer(buffer)

    def __str__(self) -> str:
        return (f"Histogram Config: EC={self.elect_calib}, PROX={self.prox}, DIST={self.distance}, "
                f"DIST_PUC={self.distance_puc}, SUM={self.summed}")

    def to_buffer(self) -> bytes:
        """
        Serialize the device information to byte buffer.

        Returns:
            Serialized device information.
        """
        buffer = (
            self.elect_calib.to_bytes(1, "little")
            + self.prox.to_bytes(1, "little")
            + self.distance.to_bytes(1, "little")
            + self.distance_puc.to_bytes(1, "little")
            + self.summed.to_bytes(1, "little")
        )
        return buffer

    def from_buffer(self, buffer: bytes) -> None:
        """
        Recover device information from byte buffer.

        Args:
            buffer: Device information serialized as byte buffer.
        """
        self.elect_calib = bool(buffer[0])
        self.prox = bool(buffer[1])
        self.distance = bool(buffer[2])
        self.distance_puc = bool(buffer[3])
        self.summed = bool(buffer[4])

    def to_flags(self) -> HistogramFlags:
        """
        Convert histogram configuration to flags.

        Returns:
            Histogram configuration as flags.
        """
        cfg_flag = HistogramFlags.NONE
        if self.elect_calib: cfg_flag |= HistogramFlags.ELECTRICAL_CAL
        if self.distance: cfg_flag |= HistogramFlags.DISTANCE
        if self.distance_puc: cfg_flag |= HistogramFlags.ALG_PILEUP
        if self.prox: cfg_flag |= HistogramFlags.PROXIMITY
        if self.summed: cfg_flag |= HistogramFlags.ALG_PU_TDC_SUM

        return cfg_flag

    def from_flags(self, flags: Union[HistogramFlags, int]) -> None:
        """
        Extract the histogram configuration from flags.

        Args:
            flags: Histogram configuration as flags.
        """
        flags = HistogramFlags(flags)
        self.elect_calib = True if HistogramFlags.ELECTRICAL_CAL in flags else False
        self.distance = True if HistogramFlags.DISTANCE in flags else False
        self.distance_puc = True if HistogramFlags.ALG_PILEUP in flags else False
        self.prox = True if HistogramFlags.PROXIMITY in flags else False
        self.summed = True if HistogramFlags.ALG_PU_TDC_SUM in flags else False


class PersistenceThresholdConfig:
    """
    Persistence and threshold configuration.

    Args:
        persistence: How many times a result needs to be in the specified range to provide a result and
            trigger an interrupt. Defaults to 0 (always).

        low_threshold: Any result that is >= then this threshold will be reported (if persistence is achieved).
            Defaults to 0.

        high_threshold: Any result that is <= this will be reported (if persistence is achieved). Defaults to 10000.


    Attributes:
        elect_calib (bool): Dump electrical calibration histogram.

        prox (bool): Dump proximity histogram.

        distance (bool): Dump distance histograms.

        distance_puc (bool): Dump pile-up corrected distance histograms.

        summed (bool): Dump a pile-up corrected summed histogram.
    """

    def __init__(self,
                 persistence: int = 0,
                 low_threshold: int = 0,
                 high_threshold: int = 10000,
                 buffer: Optional[bytes] = None) -> None:
        self.persistence = persistence
        self.low_threshold = low_threshold
        self.high_threshold = high_threshold
        if buffer is not None:
            self.from_buffer(buffer)

    def __eq__(self, __value: object) -> bool:
        if isinstance(__value, PersistenceThresholdConfig):
            equal = all([
                self.persistence == __value.persistence,
                self.low_threshold == __value.low_threshold,
                self.high_threshold == __value.high_threshold,
            ])
        else:
            equal = False

        return equal

    def to_buffer(self) -> bytes:
        """
        Serialize the device information to byte buffer.

        Returns:
            Serialized device information.
        """
        buffer = (
            self.low_threshold.to_bytes(2, "little")
            + self.high_threshold.to_bytes(2, "little")
            + self.persistence.to_bytes(1, "little")
        )
        return buffer

    def from_buffer(self, buffer: bytes) -> None:
        """
        Recover device information from byte buffer.

        Args:
            buffer: Device information serialized as byte buffer.
        """
        self.low_threshold = int().from_bytes(buffer[0:2], "little")
        self.high_threshold = int().from_bytes(buffer[2:4], "little")
        self.persistence = buffer[4]


class HistogramsAndResult:
    """class for storing a set of histograms and the associated result frame"""
    def __init__(self):
        self.histogramsEc:List[Iterable[int]] = []
        self.histogramsOc:List[Iterable[int]] = []
        self.histogramsProx:List[Iterable[int]] = []
        self.histogramsDist:List[Iterable[int]] = []
        self.histogramsProcPuc:List[Iterable[int]] = []
        self.histogramsDistPuc:List[Iterable[int]] = []
        self.histogramSum:List[int] = []
        self.result:tmf8806DistanceResultFrame = tmf8806DistanceResultFrame()


class ResultContainer:
    """
    Container to transfer result data via ZeroMQ protocol

    Args:
        data: Result and histogram data.

        buffer: Container serialized as byte buffer.
    """

    def __init__(self,
                 data: Optional[HistogramsAndResult] = None,
                 buffer: Optional[bytes] = None) -> None:
        self._results = data

        if buffer is not None:
            self.from_buffer(buffer=buffer)

    def _serialize_histogram(self, histogram: Union[List[List[int]], List[int]]) -> bytes:
        """
        Serialize histogram data to byte buffer.

        Args:
            histogram: Histogram data

        Returns:
            Serialized histogram data.
        """
        buffer = bytes()
        for value in histogram:
            if isinstance(value, int):
                buffer += value.to_bytes(4, "little")
            else:
                buffer += self._serialize_histogram(value)

        return buffer

    def _deserialize_histogram(self, buffer: bytes, offset: int, size: int, bins: int) -> List[List[int]]:
        """
        Deserialize histogram data from byte buffer.

        Args:
            buffer: Byte buffer.

            offset: Byte offset where the histogram data start.

            size: Size of the histogram data in byte.

            bins: Bins per histogram

        Returns:
            Histogram data.
        """
        return [list(e) for e in iter_unpack(f"<{bins}i", buffer[offset:offset+size])]

    @property
    def results(self) -> Union[HistogramsAndResult, None]:
        """Histogram and distance results."""
        return self._results

    def to_buffer(self) -> bytes:
        """
        Serialize the container to byte buffer.

        Returns:
            Serialized container.
        """
        header = tmf8806ContainerFrameHeader()
        payload = b''
        if self._results is not None:
            # Distance result
            offset = sizeof(header)
            header.distanceResultFrameOffset = offset
            header.distanceResultFrameSize = sizeof(self._results.result)
            payload += bytes(self._results.result)
            offset += header.distanceResultFrameSize

            # EC histogram
            buffer = self._serialize_histogram(self._results.histogramsEc)
            header.electricalCalibrationHistogramOffset = offset
            header.electricalCalibrationHistogramSize = len(buffer)
            offset += header.electricalCalibrationHistogramSize
            payload += buffer

            # Proximity histogram
            buffer = self._serialize_histogram(self._results.histogramsProx)
            header.proximityHistogramOffset = offset
            header.proximityHistogramSize = len(buffer)
            offset += header.proximityHistogramSize
            payload += buffer

            # Distance histogram
            buffer = self._serialize_histogram(self._results.histogramsDist)
            header.distanceHistogramOffset = offset
            header.distanceHistogramSize = len(buffer)
            offset += header.distanceHistogramSize
            payload += buffer

            # Distance PUC histogram
            buffer = self._serialize_histogram(self._results.histogramsDistPuc)
            header.distanceHistogramPUCOffset = offset
            header.distanceHistogramPUCSize = len(buffer)
            offset += header.distanceHistogramPUCSize
            payload += buffer

            # Summed histogram
            buffer = self._serialize_histogram(self._results.histogramSum)
            header.summedHistogramOffset = offset
            header.summedHistogramSize = len(buffer)
            offset += header.summedHistogramSize
            payload += buffer

        return bytes(header) + payload

    def from_buffer(self, buffer: bytes) -> None:
        """
        Deserialize the container from byte buffer.

        Args:
            buffer: Serialized container.
        """
        # Header
        header = tmf8806ContainerFrameHeader.from_buffer_copy(buffer)

        if (header.distanceResultFrameSize > 0
                or header.electricalCalibrationHistogramSize > 0
                or header.proximityHistogramSize > 0
                or header.distanceHistogramSize > 0
                or header.summedHistogramSize > 0):
            self._results = HistogramsAndResult()
        else:
            self._results = None

        # Distance result
        if header.distanceResultFrameSize > 0:
            self._results.result = tmf8806DistanceResultFrame.from_buffer_copy(
                buffer, header.distanceResultFrameOffset)

        # EC histogram
        if header.electricalCalibrationHistogramSize > 0:
            self._results.histogramsEc = self._deserialize_histogram(
                buffer=buffer,
                offset=header.electricalCalibrationHistogramOffset,
                size=header.electricalCalibrationHistogramSize,
                bins=256,
                )

        # Proximity histogram
        if header.proximityHistogramSize > 0:
            self._results.histogramsProx = self._deserialize_histogram(
                buffer=buffer,
                offset=header.proximityHistogramOffset,
                size=header.proximityHistogramSize,
                bins=256,
                )

        # Distance histogram
        if header.distanceHistogramSize > 0:
            self._results.histogramsDist = self._deserialize_histogram(
                buffer=buffer,
                offset=header.distanceHistogramOffset,
                size=header.distanceHistogramSize,
                bins=256,
                )

        # Distance PUC histogram
        if header.distanceHistogramPUCSize > 0:
            self._results.histogramsDistPuc = self._deserialize_histogram(
                buffer=buffer,
                offset=header.distanceHistogramPUCOffset,
                size=header.distanceHistogramPUCSize,
                bins=256,
                )

        # Summed histogram
        if header.summedHistogramSize > 0:
            self._results.histogramSum = self._deserialize_histogram(
                buffer=buffer,
                offset=header.summedHistogramOffset,
                size=header.summedHistogramSize,
                bins=256,
                )[0]


class BaseAdapterInterface:
    """Adaptor interface for ZeroMq server."""

    @staticmethod
    def device_connected() -> Any:
        """
        Check if board or sensor is connected to the device.

        Returns:
            If board or sensor is connected, a value which can interpreted
            as `True` should be returned. Could be `True`, a none empty string,
            a populated list or tuple for example.
            If no board or sensor is connected, a value which can interpreted as
            `False` should be returned. Could be `False`, empty string or empty
            list for example.
        """
        raise NotImplementedError("Not implemented")

    def open(self) -> None:
        """
        Open the communication to the device.
        """
        raise NotImplementedError("Not implemented")

    def close(self) -> None:
        """
        Close the communication to the device.
        """
        raise NotImplementedError("Not implemented")

    def identify(self) -> DeviceInfo:
        """
        Get device information

        Returns:
            Device information.

        Raises:
            CommandError: Something went wrong.
        """
        return DeviceInfo()

    def start_measurement(self, config: tmf8806MeasureCmd, cal_data: Optional[tmf8806FactoryCalibData] = None) -> None:
        """
        Start measurement.

        Args:
            config: Measurement configuration.

            cal_data: Optional, calibration data.

        Raise:
            CommandError: Starting measurement failed.
        """
        raise NotImplementedError("Not implemented")

    def stop_measurement(self) -> None:
        """
        Stop measurement.
        """
        raise NotImplementedError("Not implemented")

    def run_factory_calibration(self, config: tmf8806MeasureCmd) -> tmf8806FactoryCalibData:
        """
        Run factory calibration.

        Args:
            config: Configuration used for factory calibration.

        Returns:
            Calibration data.

        Raise:
            CommandError: Factory calibration failed.
        """
        raise NotImplementedError("Not implemented")

    def get_configuration(self) -> tmf8806MeasureCmd:
        """
        Get measurement configuration.

        Returns:
            Measurement configuration.
        """
        raise NotImplementedError("Not implemented")

    def set_histogram_config(self, config: HistogramConfig) -> None:
        """
        Set histogram dumping configuration.

        Args:
            config: Histogram dumping configuration.
        """
        raise NotImplementedError("Not implemented")

    def get_histogram_config(self) -> HistogramConfig:
        """
        Get histogram dumping configuration.

        Returns:
            Histogram dumping configuration.
        """
        raise NotImplementedError("Not implemented")

    def set_persistence_threshold_config(self, config: PersistenceThresholdConfig) -> None:
        """
        Set persistence and threshold configuration.

        Args:
            config: Persistence and threshold configuration.
        """
        raise NotImplementedError("Not implemented")

    def get_persistence_threshold_config(self) -> PersistenceThresholdConfig:
        """
        Get persistence and threshold configuration.

        Returns:
            Persistence and threshold configuration.
        """
        raise NotImplementedError("Not implemented")

    def get_data(self, timeout: float = 1.0) -> Union[HistogramsAndResult, None]:
        """
        Read result data from device.

        Args:
            timeout: Maximal wait time for new result data. If no new result data available
                `None`shall be returned.

        Returns:
            Result data.
        """
        raise NotImplementedError("Not implemented")

    def update_target_binaries(self, zip_blob: bytes) -> None:
        """
        Update the EVM software like:

            - Sensor firmware
            - Linux driver
            - ZeroMQ server

        The needed files are zip as one file. The zip file must include one file
        with the name `update.py` in the root. This file must contain all instructions to
        update the related software components and restart the system if needed.
        On server side the zip file will be unzipped. And the `update.py` will be
        executed in a new process.

        Args:
            zip_blob: Zip file as byte blob.
        """
        raise NotImplementedError("Not implemented")
