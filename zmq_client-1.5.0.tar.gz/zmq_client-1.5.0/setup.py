# /*****************************************************************************
# * Copyright (c) [2024] ams-OSRAM AG                                          *
# * All rights are reserved.                                                   *
# *                                                                            *
# * FOR FULL LICENSE TEXT SEE LICENSE.TXT                                      *
# ******************************************************************************/


from setuptools import setup
from zmq_client import __version__

setup(
    name="zmq_client",
    version=__version__,
    python_requires=">=3.6",
    install_requires=[
        "pyzmq",
    ],
    packages = [
        "zmq_client",
    ]
)
